//
//  ViewController.m
//  Interaction
//
//  Created by KT-yzx on 2019/9/20.
//  Copyright © 2019 QuickTo. All rights reserved.
//

#import "ViewController.h"
#import "BlueToothManager.h"
#import "CGPrintViewController.h"
#import "CLDrugDetailsSubResponseModel.h"
#import "SVProgressHUD.h"

@interface ViewController ()


@end

@implementation ViewController



- (void)viewDidLoad {
    
    [super viewDidLoad];
    // Do any additional setup after loading the view.

    UIButton * printButton = [UIButton buttonWithType:UIButtonTypeCustom];
    printButton.frame = CGRectMake(100, 100, 70, 70);
    [printButton setTitle:@"打印" forState:UIControlStateNormal];
    printButton.backgroundColor = [UIColor redColor];
    [printButton addTarget:self action:@selector(pressButton:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:printButton];
    
}

- (void)pressButton:(UIButton *)sender{
    BlueToothManager * _manager = [BlueToothManager getInstance];
    
   
    if (_manager && _manager._per) {//如果保存有 就链接默认保存的
        
        [self connectPrintFunc:_manager._per];
       
        
        return;
        
        
    }
    
    [self printViewFunc];
    
}

- (void)printViewFunc{
    
    CLDrugDetailsSubResponseModel * responseInfo = [[CLDrugDetailsSubResponseModel alloc] init];

    responseInfo.medNickName = @"店名";
    responseInfo.orderId = @"234324";
    responseInfo.medicalCount = @"23";
    responseInfo.transFee = @"10";
    responseInfo.reducePrice = @"233";
    responseInfo.medicalTotalAmount = @"243";
    responseInfo.createDate = @"2019-12-12";
    responseInfo.amount = @"246";
    responseInfo.userName = @"呵呵";
    responseInfo.userMobile = @"13522222222";
    responseInfo.userAddress = @"北京市北京市";
    NSMutableArray * array = [[NSMutableArray alloc] initWithCapacity:0];
    for (int i = 0; i < 6; i++) {
        CLDrugListDetailsResponseModel * response = [[CLDrugListDetailsResponseModel alloc] init];
        response.medicalId = @"245423";
        response.medicalName = @"多得是";
        response.medicalPic = @"sssssssss";
        response.medicalSpec = @"aaaa";
        response.medicalAmount = @"234";
        response.medicalCount = @"2";
        response.prodent = @"多得是e33";
        response.prescriptionflag = @"1";
        response.prescriptionflag = @"133";
        [array addObject:response];
    }
    responseInfo.medicalList = array;
    
    
    
    
    UIStoryboard * story = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    CGPrintViewController * printController = [story instantiateViewControllerWithIdentifier:@"CGPrintViewController"];
    printController.responseInfo = responseInfo;
    UINavigationController * nav = [[UINavigationController alloc] initWithRootViewController:printController];

    [self presentViewController:nav animated:YES completion:nil];
}

-(void)connectPrintFunc:(CBPeripheral *)perNew{
    // 连接
    BlueToothManager * _manager = [BlueToothManager getInstance];
    [_manager connectPeripheralWith:perNew];
    [_manager connectInfoReturn:^(CBCentralManager *central, CBPeripheral *peripheral, NSString *stateStr) {
        if ([stateStr isEqualToString:@"SUCCESS"]) {//连接成功--SUCCESS，连接失败--ERROR，断开连接--DISCONNECT
            //                [SVProgressHUD showSuccessWithStatus:@"连接蓝牙设备成功!" maskType:SVProgressHUDMaskTypeNone];
            NSLog(@"id = %@", perNew.identifier);
            
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:nil message:@"确认要打印订单吗？" delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"确定", nil];
            alert.tag = 8888;
            [alert show];
            
            
        }else{
            
            [self printViewFunc];
        }
        
    }];
}
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    
    if (alertView.tag == 8888) {
        if (buttonIndex == 1) {
            [NSTimer scheduledTimerWithTimeInterval:2.0f target:self selector:@selector(BlueToothPrint) userInfo:nil repeats:NO];
        }
    }
}
- (void)BlueToothPrint{
    CLDrugDetailsSubResponseModel * responseInfo = [[CLDrugDetailsSubResponseModel alloc] init];
    
    responseInfo.medNickName = @"店名";
    responseInfo.orderId = @"234324";
    responseInfo.medicalCount = @"23";
    responseInfo.transFee = @"10";
    responseInfo.reducePrice = @"233";
    responseInfo.medicalTotalAmount = @"243";
    responseInfo.createDate = @"2019-12-12";
    responseInfo.amount = @"246";
    responseInfo.userName = @"呵呵";
    responseInfo.userMobile = @"13522222222";
    responseInfo.userAddress = @"北京市北京市";
    NSMutableArray * array = [[NSMutableArray alloc] initWithCapacity:0];
    for (int i = 0; i < 6; i++) {
        CLDrugListDetailsResponseModel * response = [[CLDrugListDetailsResponseModel alloc] init];
        response.medicalId = @"245423";
        response.medicalName = @"多得是";
        response.medicalPic = @"sssssssss";
        response.medicalSpec = @"aaaa";
        response.medicalAmount = @"234";
        response.medicalCount = @"2";
        response.prodent = @"多得是e33";
        response.prescriptionflag = @"1";
        response.prescriptionflag = @"133";
        [array addObject:response];
    }
    responseInfo.medicalList = array;
    
    BlueToothManager * _manager = [BlueToothManager getInstance];
    [_manager getBluetoothPrintWith:responseInfo andPrintType:0];
    [_manager stopScan];
    [_manager getPrintSuccessReturn:^(BOOL sizeValue) {
        if (sizeValue==YES) {
            [SVProgressHUD showSuccessWithStatus:@"打印成功!" maskType:SVProgressHUDMaskTypeNone];
        }else{
            [SVProgressHUD showInfoWithStatus:@"打印失败!"];
        }
    }];
    
}

@end
