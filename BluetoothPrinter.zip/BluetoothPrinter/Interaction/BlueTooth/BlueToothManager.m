//
//  BlueToothManager.m
//  BluetoothPrint
//
//  Created by Tgs on 16/3/7.
//  Copyright © 2016年 Tgs. All rights reserved.
//

#import "BlueToothManager.h"
#define kServiceUUID @"00001101-0000-1000-8000-00805F9B34FB"

@implementation BlueToothManager
@synthesize _per;
//创建单例类
+(instancetype)getInstance
{
    static BlueToothManager * manager = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        manager = [[BlueToothManager alloc]init];
        
    });
    return manager;
    
}

//开始扫描
- (void)startScan
{
    //    [LCProgressHUD showLoadingText:@"正在扫描"];
    
    _manager = [[CBCentralManager alloc]initWithDelegate:self queue:dispatch_get_main_queue()];
    _peripheralList = [[NSMutableArray alloc]initWithCapacity:0];
}

//停止扫描
-(void)stopScan
{
    [_manager stopScan];
    
}

//检查蓝牙信息
-(void)centralManagerDidUpdateState:(CBCentralManager *)central
{
    if (central.state == CBCentralManagerStatePoweredOn)
    {
        NSLog(@"蓝牙打开，开始扫描");
        [central scanForPeripheralsWithServices:nil options:nil];
    }
    else
    {
        NSLog(@"蓝牙不可用");
    }
}

//扫描到的设备
-(void)centralManager:(CBCentralManager *)central didDiscoverPeripheral:(CBPeripheral *)peripheral advertisementData:(NSDictionary<NSString *,id> *)advertisementData RSSI:(NSNumber *)RSSI
{
    NSLog(@"%@===%@",peripheral.name,RSSI);

    if (peripheral) {
      
        [_peripheralList addObject:peripheral];
        
        if (bluetoothListArr) {
            bluetoothListArr(_peripheralList);
        }
    }

}
-(void)getBlueListArray:(void (^)(NSMutableArray *blueToothArray))listBlock{
    bluetoothListArr = [listBlock copy];
}
//获取扫描到设备的列表
-(NSMutableArray *)getNameList
{
    
    return _peripheralList;
    
}

//连接设备
-(void)connectPeripheralWith:(CBPeripheral *)per
{
    if (per!=nil) {
        valuePrint = NO;
        self._per = nil;
        _char = nil;
        _readChar = nil;
        [_manager connectPeripheral:per options:nil];
    }
}

//连接设备失败
-(void)centralManager:(CBCentralManager *)central didFailToConnectPeripheral:(CBPeripheral *)peripheral error:(NSError *)error
{
    if (conReturnBlock) {
        conReturnBlock(central,peripheral,@"ERROR");
    }
        NSLog(@">>>连接到名称为（%@）的设备-失败,原因:%@",[peripheral name],[error localizedDescription]);
}

//设备断开连接
-(void)centralManager:(CBCentralManager *)central didDisconnectPeripheral:(CBPeripheral *)peripheral error:(NSError *)error
{
    if (conReturnBlock) {
        conReturnBlock(central,peripheral,@"DISCONNECT");
    }
    NSLog(@">>>外设连接断开连接 %@: %@\n", [peripheral name], [error localizedDescription]);
}

//连接设备成功
-(void)centralManager:(CBCentralManager *)central didConnectPeripheral:(CBPeripheral *)peripheral
{
    self._per = peripheral;
    
//    NSMutableData* data = [[NSMutableData alloc]init];
//    NSKeyedArchiver* archiver = [[NSKeyedArchiver alloc]initForWritingWithMutableData:data];
//    [archiver encodeObject:self._per];
//    [archiver finishEncoding];,
//
    NSString * uuidNew = [NSString stringWithFormat:@"%@", self._per.identifier.UUIDString];
    [[NSUserDefaults standardUserDefaults] setObject:uuidNew forKey:@"BlueToothManagerPer"];
    
//
//        NSDictionary * userPerDict = [[NSUserDefaults standardUserDefaults] valueForKey:@"BlueToothManagerPer"];
//        CBPeripheral * per = (CBPeripheral *)[NSKeyedUnarchiver unarchiveObjectWithData: [userPerDict objectForKey:@"userPer"]];
    
        
        
        
    [_per setDelegate:self];
    [_per discoverServices:nil];
    
}
//成功回调
-(void)connectInfoReturn:(void(^)(CBCentralManager *central ,CBPeripheral *peripheral,NSString *stateStr))myBlock{
    conReturnBlock = [myBlock copy];
}
//扫描设备的服务
-(void)peripheral:(CBPeripheral *)peripheral didDiscoverServices:(NSError *)error
{
    if (error)
    {
                NSLog(@"扫描%@的服务发生的错误是：%@",peripheral.name,[error localizedDescription]);
        
    }
    else
    {
        for (CBService *service in peripheral.services) {
            [peripheral discoverCharacteristics:nil forService:service];
        }
        if (conReturnBlock) {
            conReturnBlock(nil,peripheral,@"SUCCESS");
        }
    }
}



//扫描服务的特征值
-(void)peripheral:(CBPeripheral *)peripheral didDiscoverCharacteristicsForService:(CBService *)service error:(NSError *)error
{
    
    if (error)
    {
            NSLog(@"扫描服务：------->%@的特征值的错误是：%@",service.UUID,[error localizedDescription]);
    }
    else
    {
        for (CBCharacteristic * cha in service.characteristics)
        {
            CBCharacteristicProperties p = cha.properties;
            if (p & CBCharacteristicPropertyBroadcast) {
            }
            if (p & CBCharacteristicPropertyRead) {
            }
            if (p & CBCharacteristicPropertyWriteWithoutResponse) {
                _char = cha;
                               NSLog(@"WriteWithoutResponse---扫描服务：%@的特征值为：%@",service.UUID,cha.UUID);
            }
            if (p & CBCharacteristicPropertyWrite) {
                              NSLog(@"Write---扫描服务：%@的特征值为：%@",service.UUID,cha.UUID);
            }
            if (p & CBCharacteristicPropertyNotify) {
                _readChar = cha;
            }
            [_per readValueForCharacteristic:cha];
            [_per discoverDescriptorsForCharacteristic:cha];
        }
    }
}

//获取特征值的信息
-(void)peripheral:(CBPeripheral *)peripheral didUpdateValueForCharacteristic:(CBCharacteristic *)characteristic error:(NSError *)error
{
    if (error)
    {
               NSLog(@"获取特征值%@的错误为%@",characteristic.UUID,error);
        
    }
    else
    {
               NSLog(@"------->特征值：%@  value：%@",characteristic.UUID,characteristic.value);
        _responseData = characteristic.value;
        
    }
}

//扫描特征值的描述
-(void)peripheral:(CBPeripheral *)peripheral didDiscoverDescriptorsForCharacteristic:(CBCharacteristic *)characteristic error:(NSError *)error
{
    if (error)
    {
               NSLog(@"搜索到%@的Descriptors的错误是：%@",characteristic.UUID,error);
        
    }
    else
    {
              NSLog(@",,,,,,,,,,,characteristic uuid:%@",characteristic.UUID);
        //
        //        for (CBDescriptor * d in characteristic.descriptors)
        //        {
        //            NSLog(@"------->Descriptor uuid:%@",d.UUID);
        //
        //        }
    }
}

//获取描述值的信息
-(void)peripheral:(CBPeripheral *)peripheral didUpdateValueForDescriptor:(CBDescriptor *)descriptor error:(NSError *)error
{
       if (error)
        {
            NSLog(@"获取%@的描述的错误是：%@",peripheral.name,error);
        }
       else
    {
            NSLog(@"characteristic uuid:%@  value:%@",[NSString stringWithFormat:@"%@",descriptor.UUID],descriptor.value);
    
        }
}

//像蓝牙发送信息
- (void)sendDataWithString:(NSString *)str andInfoData:(NSData *)infoData
{
    if (_per==nil||_char==nil) {
        valuePrint = NO;
        if (conReturnBlock) {
            conReturnBlock(nil ,nil,@"BLUEDISS");
            return;
        }
    }else{
        valuePrint = YES;
        if (str==nil||str.length==0) {
            if (_per && _char)
            {
                switch (_char.properties & 0x04) {
                    case CBCharacteristicPropertyWriteWithoutResponse:
                    {
                        [_per writeValue:infoData forCharacteristic:_char type:CBCharacteristicWriteWithoutResponse];
                        break;
                        
                    }
                    default:
                    {
                        [_per writeValue:infoData forCharacteristic:_char type:CBCharacteristicWriteWithoutResponse];
                        break;
                    }
                }
                
            }
            
        }else{
            NSData * data = [str dataUsingEncoding:NSUTF8StringEncoding];
            if (_per && _char)
            {
                switch (_char.properties & 0x04) {
                    case CBCharacteristicPropertyWriteWithoutResponse:
                    {
                        [_per writeValue:data forCharacteristic:_char type:CBCharacteristicWriteWithoutResponse];
                        break;
                        
                    }
                    default:
                    {
                        [_per writeValue:data forCharacteristic:_char type:CBCharacteristicWriteWithoutResponse];
                        break;
                    }
                }
                
            }
        }
        
    }
    
}
-(void)getPrintSuccessReturn:(void(^)(BOOL sizeValue))printBlock{
    printSuccess = [printBlock copy];
}
//展示蓝牙返回的信息
-(void)showResult
{
    if (printSuccess&&valuePrint==YES) {
        printSuccess(YES);
    }
}

-(void)getBluetoothPrintWith:(CLDrugDetailsSubResponseModel *)infoModel andPrintType:(NSInteger)typeNum{
    
    
//
//    //    初始化打印机
    Byte insuArray[] ={ 0x1B,0x40};
    NSData *InsuData= [NSData dataWithBytes: insuArray length: sizeof(insuArray)];
    
    //    初始化打印机 清除
    Byte insuArraya[] ={ 16,5,2};
    NSData *InsuDataaa= [NSData dataWithBytes: insuArray length: sizeof(insuArraya)];
    
//    //换行
    Byte array[] ={ 0x0A};
    NSData *data1= [NSData dataWithBytes: array length: sizeof(array)];
    //设置字体大小
    //    Byte array3[] = {0x1D,0x21,10};//放大横向、纵向各一倍
    //    NSData *data3= [NSData dataWithBytes: array3 length: sizeof(array3)];
    //    Byte ziti1[] = {0x1D,0x21,00};//取消字体放大
    //    NSData *ziti= [NSData dataWithBytes: ziti1 length: sizeof(ziti1)];
    //居中
    Byte array4[] = {0x1B,0x61,1};
    NSData *data4= [NSData dataWithBytes: array4 length: sizeof(array4)];
    //居左
    Byte array6[] = {0x1B,0x61,0};
    NSData *data6= [NSData dataWithBytes: array6 length: sizeof(array6)];
    //居右
    Byte array66[] = {0x1B,0x61,2};
    NSData * data66 = [NSData dataWithBytes:array66 length:sizeof(array66)];
    //粗体打印
    Byte array5[] = {0x1B,0x45,0};
    NSData *data5= [NSData dataWithBytes: array5 length: sizeof(array5)];
    
    Byte array12[] ={ 10};
    NSData *data12= [NSData dataWithBytes: array12 length: sizeof(array12)];

//    NSMutableData *mainData0 = [[NSMutableData alloc]init];
//    
//    [mainData0 appendData:InsuData];//初始化
//    [mainData0 appendData:InsuDataaa];
//    
//    [self sendDataWithString:nil andInfoData:mainData0];//线条
    
    
    for (int n = 0; n < 2; n++) {//客户 和 药店 用到的小票
        //头部
        NSString *title = @"";

        if (n == 0) {
            title = @"客户留用";
        }else if (n == 1){
            title = @"药店留用";
        }
        sleep(1);
        NSStringEncoding enca = CFStringConvertEncodingToNSStringEncoding(kCFStringEncodingGB_18030_2000);
        NSData *titleData = [title dataUsingEncoding:enca];
        
        //    店铺名字
        NSString *STR1 = [NSString stringWithFormat:@"%@", infoModel.medNickName];
        NSData *shopNameData = [STR1 dataUsingEncoding:enca];
        
        NSString *yuyue = [NSString stringWithFormat:@"预约号:%@", infoModel.orderId];
        NSData *yuyueData = [yuyue dataUsingEncoding:enca];
        
//        NSString *str2 = @"- - - - - - - - - - - - - - - -";
//        NSData *xiantiao = [str2 dataUsingEncoding:enca];
        
        
        
        NSMutableData *mainData = [[NSMutableData alloc]init];
        
        [mainData appendData:InsuData];//初始化
        [mainData appendData:InsuDataaa];
        [mainData appendData:data1];//换行
        [mainData appendData:data66];//居右
        [mainData appendData:titleData];//医护到家----文本
        [mainData appendData:data12];//换行
        [mainData appendData:data12];//换行
        [self sendDataWithString:nil andInfoData:mainData];//线条
        
        NSMutableData *mainData2 = [[NSMutableData alloc]init];
        
        [mainData2 appendData:data4];//居中
        [mainData2 appendData:shopNameData];//店名字
        [mainData2 appendData:data12];//换行
        [self sendDataWithString:nil andInfoData:mainData2];//
        
        NSMutableData *mainData3 = [[NSMutableData alloc]init];
        
        [mainData3 appendData:data4];//居中
        [mainData3 appendData:yuyueData];//预约号
        [mainData3 appendData:data12];//换行
        [mainData3 appendData:data12];//换行
        [self sendDataWithString:nil andInfoData:mainData3];//
        
//        NSMutableData *mainData4 = [[NSMutableData alloc]init];
//        [mainData4 appendData:data4];//居中
//        [mainData4 appendData:xiantiao];//线条
//        [mainData4 appendData:data12];//换行
//        [self sendDataWithString:nil andInfoData:mainData4];//
        ///////////////////////////////////////////////////////////////
        
        
        //药品列表
        for (int i = 0; i < [infoModel.medicalList count]; i++) {
            sleep(1);
            CLDrugListDetailsResponseModel * listInfo = [infoModel.medicalList objectAtIndex:i];
            
            
            NSString *yaopinNamge = [NSString stringWithFormat:@"药品名称:%@", listInfo.medicalName];
            NSData *yaopindata = [yaopinNamge dataUsingEncoding:enca];
            
            NSString *changjiaName = [NSString stringWithFormat:@"厂家:%@", listInfo.prodent];
            NSData *changjiadata = [changjiaName dataUsingEncoding:enca];
            
            NSString *guigeNamge = [NSString stringWithFormat:@"规格:%@", listInfo.medicalSpec];
            NSData * guigedata = [guigeNamge dataUsingEncoding:enca];
            
            NSString *proL = @"单价         数量          金额";
            NSData *proData = [proL dataUsingEncoding:enca];
            NSString * danjia = [NSString stringWithFormat:@"￥%@", listInfo.medicalAmount];;
            NSString * shuliang = listInfo.medicalCount;
            
            CGFloat zong = [listInfo.medicalAmount floatValue] * [listInfo.medicalCount intValue];
            
            NSString * jine = [NSString stringWithFormat:@"￥%.2f", zong];
            
            //计算价格的分部
            int strLeng = 384 - [danjia length]*12 - [shuliang length]*12 - [jine length]*12 - 24;
            
            int kongge = strLeng/12;
            
            NSString * newString = danjia;
            for (int i = 0; i < kongge/2; i++) {
                newString = [NSString stringWithFormat:@"%@ ", newString];
            }
            newString = [NSString stringWithFormat:@"%@%@", newString, shuliang];
            
            for (int i = 0; i < kongge/2; i++) {
                newString = [NSString stringWithFormat:@"%@ ", newString];
            }
            
            newString = [NSString stringWithFormat:@"%@%@", newString, jine];
            NSData * jineData = [newString dataUsingEncoding:enca];
            ///////////////////////////////////////////////////////////////////
            
            
            NSMutableData *mainData5 = [[NSMutableData alloc]init];
//            [mainData5 appendData:InsuData];//初始化
//            [mainData5 appendData:InsuDataaa];
            [mainData5 appendData:data6];//居左
            [mainData5 appendData:yaopindata];//药品名称
            [mainData5 appendData:data12];//换行
            [self sendDataWithString:nil andInfoData:mainData5];//
            
            
            NSMutableData *mainData6 = [[NSMutableData alloc]init];
            
            [mainData6 appendData:data6];//居左
            [mainData6 appendData:changjiadata];//厂家地址
            [mainData6 appendData:data12];//换行
            [self sendDataWithString:nil andInfoData:mainData6];//
            
            NSMutableData *mainData7 = [[NSMutableData alloc]init];
            
            [mainData7 appendData:data6];//居左
            [mainData7 appendData:guigedata];//药品规格
            [mainData7 appendData:data12];//换行
            [self sendDataWithString:nil andInfoData:mainData7];//
            
            NSMutableData *mainData8 = [[NSMutableData alloc]init];
            
            [mainData8 appendData:data4];//换行
            [mainData8 appendData:proData];//名称数量
            [mainData8 appendData:data12];//换行
            [self sendDataWithString:nil andInfoData:mainData8];//
            
            NSMutableData *mainData12 = [[NSMutableData alloc]init];
            [mainData12 appendData:data6];//居右
            [mainData12 appendData:jineData];//总价格
            [mainData12 appendData:data12];//换行
            [mainData12 appendData:data12];//换行
            [self sendDataWithString:nil andInfoData:mainData12];//
            
            
        }
        
//        NSString *str3 = @"- - - - - - - - - - - - - - - -";
//        NSData *xiantiao3 = [str3 dataUsingEncoding:enca];
        
        
//        NSMutableData *mainData13 = [[NSMutableData alloc]init];
//        [mainData13 appendData:xiantiao3];//
//        [mainData13 appendData:data12];//换行
//        [self sendDataWithString:nil andInfoData:mainData13];//
        
        ////////////////////////////////////////////////////////////
        
        
        ///尾部
        NSString * heji = [NSString stringWithFormat:@"合计:%@", infoModel.medicalCount];
        NSData *hejidata = [heji dataUsingEncoding:enca];
        
        NSMutableData *mainData14 = [[NSMutableData alloc]init];
//        [mainData14 appendData:InsuData];//初始化
//        [mainData14 appendData:InsuDataaa];
        [mainData14 appendData:data6];//居左
        [mainData14 appendData:hejidata];//合计
        [mainData14 appendData:data12];//换行
        [self sendDataWithString:nil andInfoData:mainData14];//
        
        NSString * peisongfei = [NSString stringWithFormat:@"配送费:￥%@", infoModel.transFee];
        NSData *peisongfeiData = [peisongfei dataUsingEncoding:enca];
        
        NSMutableData *mainData15 = [[NSMutableData alloc]init];
        
        [mainData15 appendData:data6];//居左
        [mainData15 appendData:peisongfeiData];//配送费 没有
        [mainData15 appendData:data12];//换行
        [self sendDataWithString:nil andInfoData:mainData15];//
        
        
        NSString * youhui = [NSString stringWithFormat:@"优  惠:￥%@", infoModel.reducePrice];
        NSData *youhuiData = [youhui dataUsingEncoding:enca];
        
        NSMutableData *mainData16 = [[NSMutableData alloc]init];
        
        [mainData16 appendData:data6];//居左
        [mainData16 appendData:youhuiData];//优惠 没有
        [mainData16 appendData:data12];//换行
        [self sendDataWithString:nil andInfoData:mainData16];//
        
        NSString * zongjine = [NSString stringWithFormat:@"应收金额:￥%@", infoModel.amount];
        NSData *zongjinedata = [zongjine dataUsingEncoding:enca];
        
        NSMutableData *mainData17 = [[NSMutableData alloc]init];
        
        [mainData17 appendData:data6];//居左
        [mainData17 appendData:zongjinedata];//总金额
        [mainData17 appendData:data12];//换行
        [self sendDataWithString:nil andInfoData:mainData17];//
        
        
        NSString * riqi = [NSString stringWithFormat:@"日期:%@", infoModel.createDate];
        NSData * riqiData = [riqi dataUsingEncoding:enca];
        
        NSMutableData *mainData18 = [[NSMutableData alloc]init];
        
        [mainData18 appendData:data6];//居左
        [mainData18 appendData:riqiData];//总金额
        [mainData18 appendData:data12];//换行
        [mainData18 appendData:data12];//换行
        [self sendDataWithString:nil andInfoData:mainData18];//
        
//        NSString *str4 = @"- - - - - - - - - - - - - - - -";
//        NSData *xiantiao4 = [str4 dataUsingEncoding:enca];
        
        
//        NSMutableData *mainData19 = [[NSMutableData alloc]init];
//        [mainData19 appendData:data12];//换行
//        [mainData19 appendData:xiantiao4];//
//        [mainData19 appendData:data12];//换行
//        [self sendDataWithString:nil andInfoData:mainData19];//
        
        if (n == 0) {
            NSString *shuoming = @"药品属特殊商品，如无质量问题，一经售出概不退换";
            NSData *shuomingData = [shuoming dataUsingEncoding:enca];
            
            NSMutableData *mainData20 = [[NSMutableData alloc]init];
            [mainData20 appendData:data6];//居左
            [mainData20 appendData:shuomingData];//
            [mainData20 appendData:data12];//换行
            [self sendDataWithString:nil andInfoData:mainData20];//
            
            NSString *shouji = @"电话:4000-123-789";
            NSData *shoujidata = [shouji dataUsingEncoding:enca];
            
            NSMutableData *mainData21 = [[NSMutableData alloc]init];
            [mainData21 appendData:data6];//居左
            [mainData21 appendData:shoujidata];//
            [mainData21 appendData:data12];//换行
            [mainData21 appendData:data12];//换行
            [self sendDataWithString:nil andInfoData:mainData21];//
            
//            NSString *str5 = @"- - - - - - - - - - - - - - - -";
//            NSData *xiantiao5 = [str5 dataUsingEncoding:enca];
//            NSMutableData *mainData22 = [[NSMutableData alloc]init];
//            [mainData22 appendData:data12];//换行
//            [mainData22 appendData:xiantiao5];//
//            [mainData22 appendData:data12];//换行
//            [self sendDataWithString:nil andInfoData:mainData22];//
        }

        NSString * shishou = [NSString stringWithFormat: @"实收:￥%@", infoModel.amount];
        NSData *shishouData = [shishou dataUsingEncoding:enca];
        
        
        NSMutableData *mainData23 = [[NSMutableData alloc]init];
        [mainData23 appendData:data6];//居左
        [mainData23 appendData:shishouData];//
        [mainData23 appendData:data12];//换行
        [self sendDataWithString:nil andInfoData:mainData23];//
        
        NSString * yonghu = [NSString stringWithFormat: @"用户:%@", infoModel.userName];
        NSData *yonghuData = [yonghu dataUsingEncoding:enca];
        
        
        NSMutableData *mainData24 = [[NSMutableData alloc]init];
        [mainData24 appendData:data6];//居左
        [mainData24 appendData:yonghuData];//
        [mainData24 appendData:data12];//换行
        [self sendDataWithString:nil andInfoData:mainData24];//
        
        
        NSString * dianhuadingdan = [NSString stringWithFormat: @"电话:%@", infoModel.userMobile];
        NSData *dianhuadingdandata = [dianhuadingdan dataUsingEncoding:enca];
        
        
        NSMutableData *mainData25 = [[NSMutableData alloc]init];
        [mainData25 appendData:data6];//居左
        [mainData25 appendData:dianhuadingdandata];//
        [mainData25 appendData:data12];//换行
        [self sendDataWithString:nil andInfoData:mainData25];//
        
        
        NSString * dizhiDingdan = [NSString stringWithFormat: @"地址:%@", infoModel.userAddress];
        NSData *dizhiDingdandata = [dizhiDingdan dataUsingEncoding:enca];
        
        
        NSMutableData *mainData26 = [[NSMutableData alloc]init];
        [mainData26 appendData:data6];//居左
        [mainData26 appendData:dizhiDingdandata];//
        [mainData26 appendData:data12];//换行
     

        [self sendDataWithString:nil andInfoData:mainData26];//
        
        
        NSString *str6 = @"- - - - - - - - - - - - - - - -";
        NSData *xiantiao6 = [str6 dataUsingEncoding:enca];
        
        
        NSMutableData *mainData27 = [[NSMutableData alloc]init];
        [mainData27 appendData:data12];//换行
        [mainData27 appendData:xiantiao6];//
        [mainData27 appendData:data12];//换行
        [mainData27 appendData:data12];//换行
        [self sendDataWithString:nil andInfoData:mainData27];//
    }
    

    //送药员的打印
    NSString *title = @"送药员留用";
    sleep(1);
    
    NSStringEncoding enca = CFStringConvertEncodingToNSStringEncoding(kCFStringEncodingGB_18030_2000);
    NSData *titleData = [title dataUsingEncoding:enca];
    
    //    店铺名字
    NSString *STR1 = [NSString stringWithFormat:@"医护到家"];
    NSData *shopNameData = [STR1 dataUsingEncoding:enca];
    
    NSString *yuyue = [NSString stringWithFormat:@"预约号:%@", infoModel.orderId];
    NSData *yuyueData = [yuyue dataUsingEncoding:enca];
    
//    NSString *str2 = @"- - - - - - - - - - - - - - - -";
//    NSData *xiantiao = [str2 dataUsingEncoding:enca];
    
    
    
    NSMutableData *mainData = [[NSMutableData alloc]init];
//    [mainData appendData:InsuData];//初始化
//    [mainData appendData:InsuDataaa];
//    [mainData appendData:InsuData];//初始化
    [mainData appendData:data12];//换行
    [mainData appendData:data66];//居右
    [mainData appendData:titleData];//医护到家----文本
    [mainData appendData:data12];//换行
    [mainData appendData:data12];//换行
    [self sendDataWithString:nil andInfoData:mainData];//线条
    
    NSMutableData *mainData2 = [[NSMutableData alloc]init];
    
    [mainData2 appendData:data4];//居中
    [mainData2 appendData:shopNameData];//店名字
    [mainData2 appendData:data12];//换行
    [self sendDataWithString:nil andInfoData:mainData2];//
    
    NSMutableData *mainData3 = [[NSMutableData alloc]init];
    
    [mainData3 appendData:data4];//居中
    [mainData3 appendData:yuyueData];//预约号
    [mainData3 appendData:data12];//换行
    [self sendDataWithString:nil andInfoData:mainData3];//
    
//    NSMutableData *mainData4 = [[NSMutableData alloc]init];
//    [mainData4 appendData:data4];//居中
//    [mainData4 appendData:xiantiao];//线条
//    [mainData4 appendData:data12];//换行
//    [self sendDataWithString:nil andInfoData:mainData4];//
    
    NSString * yonghu = [NSString stringWithFormat: @"姓名:%@", infoModel.userName];
    NSData *yonghuData = [yonghu dataUsingEncoding:enca];
    
    
    NSMutableData *mainData24 = [[NSMutableData alloc]init];
    [mainData24 appendData:data6];//居左
    [mainData24 appendData:yonghuData];//
    [mainData24 appendData:data12];//换行
    [self sendDataWithString:nil andInfoData:mainData24];//
    
    
    NSString * dianhuadingdan = [NSString stringWithFormat: @"电话:%@", infoModel.userMobile];
    NSData *dianhuadingdandata = [dianhuadingdan dataUsingEncoding:enca];
    
    
    NSMutableData *mainData25 = [[NSMutableData alloc]init];
    [mainData25 appendData:data6];//居左
    [mainData25 appendData:dianhuadingdandata];//
    [mainData25 appendData:data12];//换行
    [self sendDataWithString:nil andInfoData:mainData25];//
    
    
    NSString * dizhiDingdan = [NSString stringWithFormat: @"地址:%@", infoModel.userAddress];
    NSData *dizhiDingdandata = [dizhiDingdan dataUsingEncoding:enca];
    
    
    NSMutableData *mainData26 = [[NSMutableData alloc]init];
    [mainData26 appendData:data6];//居左
    [mainData26 appendData:dizhiDingdandata];//
    [mainData26 appendData:data12];//换行
    [self sendDataWithString:nil andInfoData:mainData26];//

    NSString * zongjine = [NSString stringWithFormat:@"总金额:￥%@", infoModel.amount];
    NSData *zongjinedata = [zongjine dataUsingEncoding:enca];
    
    NSMutableData *mainData17 = [[NSMutableData alloc]init];
    
    [mainData17 appendData:data6];//居左
    [mainData17 appendData:zongjinedata];//总金额
    [mainData17 appendData:data12];//换行
    [mainData17 appendData:data12];//换行
    [self sendDataWithString:nil andInfoData:mainData17];//
    
    
    NSString * dianpu = [NSString stringWithFormat:@"由%@出库", infoModel.medNickName];
    NSData * dianpudata = [dianpu dataUsingEncoding:enca];

    NSMutableData *mainData18 = [[NSMutableData alloc]init];
    
    [mainData18 appendData:data4];//居左
    [mainData18 appendData:dianpudata];//
    [mainData18 appendData:data12];//换行
    [mainData18 appendData:data12];//换行
    [mainData18 appendData:data12];//换行
    [mainData18 appendData:data12];//换行

    [self sendDataWithString:nil andInfoData:mainData18];//
    
    
    valuePrint = NO;
    [self openNotify];
    [self showResult];
}

//隐藏HUD
- (void)hideHUD {
    
    //    [LCProgressHUD hide];
}

//打开通知
-(void)openNotify
{
    if (_readChar!=nil&&_per!=nil) {
        [_per setNotifyValue:YES forCharacteristic:_readChar];
    }
}

//关闭通知
-(void)cancelNotify
{
    [_per setNotifyValue:NO forCharacteristic:_readChar];
    
}

//断开连接
-(void)cancelPeripheralWith:(CBPeripheral *)per
{
    [_manager cancelPeripheralConnection:_per];
    self._per = nil;
    
}
- (void)managerIdentifiers:(NSUUID *)identifiers{

    NSMutableArray * array = [[NSMutableArray alloc] initWithCapacity:0];
    [array addObject:identifiers];
    NSArray *  perArray = [_manager  retrievePeripheralsWithIdentifiers:array];

    for (CBPeripheral * per in perArray) {
        NSLog(@"per = %@", per);
        [self connectPeripheralWith:per];
    }
}


@end
