//
//  CLDrugDetailsSubResponseModel.m
//  Interaction
//
//  Created by KT-yzx on 2019/9/25.
//  Copyright © 2019 QuickTo. All rights reserved.
//

#import "CLDrugDetailsSubResponseModel.h"

@implementation CLDrugDetailsSubResponseModel

@end

@implementation CLDrugListDetailsResponseModel



@end
