//
//  CGPrintTableViewCell.m
//  HealthCareO2OForProvider
//
//  Created by houchenguang on 16/3/27.
//  Copyright © 2016年 vodone.com. All rights reserved.
//

#import "CGPrintTableViewCell.h"

@implementation CGPrintTableViewCell


//- (IBAction)pressTypeButton:(id)sender{
//    
//    
//}


- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
