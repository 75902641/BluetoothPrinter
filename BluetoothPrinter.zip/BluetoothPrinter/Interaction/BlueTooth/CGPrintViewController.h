//
//  CGPrintViewController.h
//  HealthCareO2OForProvider
//
//  Created by houchenguang on 16/3/27.
//  Copyright © 2016年 vodone.com. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CLDrugDetailsSubResponseModel.h"

@interface CGPrintViewController : UIViewController{

    CLDrugDetailsSubResponseModel * responseInfo;
}
@property (nonatomic, retain)CLDrugDetailsSubResponseModel * responseInfo;
@property (nonatomic, weak)IBOutlet UITableView * myTableView;

- (IBAction)pressDoBack:(id)sender;

@end
