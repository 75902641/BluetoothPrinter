//
//  CLDrugDetailsSubResponseModel.h
//  Interaction
//
//  Created by KT-yzx on 2019/9/25.
//  Copyright © 2019 QuickTo. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JSONModel.h"

NS_ASSUME_NONNULL_BEGIN

@protocol CLDrugListDetailsResponseModel <NSObject>

@end

@interface CLDrugListDetailsResponseModel : JSONModel

@property (nonatomic, copy) NSString <Optional>*medicalId;//药品编号
@property (nonatomic, copy) NSString <Optional>*medicalName;//药品名称
@property (nonatomic, copy) NSString <Optional>*medicalPic;//药品小图标
@property (nonatomic, copy) NSString <Optional>*medicalSpec;//药品规格
@property (nonatomic, copy) NSString <Optional>*medicalAmount;//药品单价
@property (nonatomic, copy) NSString <Optional>*medicalCount;//药品数量
@property (nonatomic, copy) NSString <Optional>*prodent;//厂家
@property (nonatomic, copy) NSString <Optional>*prescriptionflag;//是否为处方药 0，非处方；1，处方
@property (nonatomic, copy) NSString <Optional>*promotionPrice;//促销价格


@end


@interface CLDrugDetailsSubResponseModel : JSONModel

@property (nonatomic, copy) NSString <Optional>*medNickName;//卖药人药店名称
@property (nonatomic, copy) NSString <Optional>*orderId;//订单ID
@property (nonatomic, strong) NSArray <CLDrugListDetailsResponseModel,Optional>*medicalList;//药品列表
@property (nonatomic, copy) NSString <Optional>*medicalCount;//药品总件数
@property (nonatomic, copy) NSString <Optional>*transFee;//运费
@property (nonatomic, copy) NSString <Optional>*reducePrice;//已优惠多少钱
@property (nonatomic, copy) NSString <Optional>*medicalTotalAmount;//总额
@property (nonatomic, copy) NSString <Optional>*createDate;//创建时间
@property (nonatomic, copy) NSString <Optional>*amount;//订单总金额
@property (nonatomic, copy) NSString <Optional>*userName;//订单发起人姓名
@property (nonatomic, copy) NSString <Optional>*userMobile;//订单发起人电话
@property (nonatomic, copy) NSString <Optional>*userAddress;//订单发起人地址

@end

NS_ASSUME_NONNULL_END
