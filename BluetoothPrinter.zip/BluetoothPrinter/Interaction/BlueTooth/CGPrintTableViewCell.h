//
//  CGPrintTableViewCell.h
//  HealthCareO2OForProvider
//
//  Created by houchenguang on 16/3/27.
//  Copyright © 2016年 vodone.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CGPrintTableViewCell : UITableViewCell
@property (nonatomic, weak)IBOutlet UILabel * nameLabel;
@property (nonatomic, weak)IBOutlet UIImageView * typeImageView;

//- (IBAction)pressTypeButton:(id)sender;
@end
