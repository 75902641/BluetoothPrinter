//
//  CGPrintViewController.m
//  HealthCareO2OForProvider
//
//  Created by houchenguang on 16/3/27.
//  Copyright © 2016年 vodone.com. All rights reserved.
//

#import "CGPrintViewController.h"
#import "CGPrintTableViewCell.h"
#import "BlueToothManager.h"
#import "SVProgressHUD.h"
#import "CLDrugDetailsSubResponseModel.h"


@interface CGPrintViewController ()<UITableViewDelegate,UITableViewDataSource>
{
    
    NSMutableArray * _peripheralList;
    BlueToothManager * _manager;
}

@end

@implementation CGPrintViewController
@synthesize responseInfo;
- (void)viewDidLoad {
    [super viewDidLoad];

    _manager = [BlueToothManager getInstance];
    [_manager startScan];
    [_manager getBlueListArray:^(NSMutableArray *blueToothArray) {
        _peripheralList = blueToothArray;
        [self.myTableView reloadData];
    }];
    [NSTimer scheduledTimerWithTimeInterval:1.5f target:self selector:@selector(getNameListInfo) userInfo:nil repeats:NO];
}

-(void)getNameListInfo
{
    _peripheralList = [_manager getNameList];
    [self.myTableView reloadData];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

#pragma mark - Table view data source

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 40;
}
-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    UIView *backView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, self.myTableView.frame.size.width, 40)];
    backView.backgroundColor = [UIColor colorWithRed:228/255.0 green:235/255.0 blue:235/255.0 alpha:1];
    UILabel *labelaa = [[UILabel alloc]initWithFrame:CGRectMake(10, 0, 200, 40)];
    labelaa.backgroundColor = [UIColor clearColor];
    labelaa.text = @"蓝牙设备";
    labelaa.font = [UIFont systemFontOfSize:15];
    labelaa.textColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.87];
    [backView addSubview:labelaa];
    return backView;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return _peripheralList.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    return 45;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {

    static NSString *CellIdentifier = @"CGPrintTableViewCell";
    
    CGPrintTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (!cell) {
        cell = [[CGPrintTableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:CellIdentifier];
    }
    
    CBPeripheral * per = _peripheralList[indexPath.row];
    
    cell.nameLabel.text = per.name;
     cell.typeImageView.image = [UIImage imageNamed:@"print_image_1.png"];
    if (_manager._per) {
        
        
        if ([_manager._per.identifier isEqual:per.identifier]) {
            cell.typeImageView.image = [UIImage imageNamed:@"print_image.png"];
        }else{
            cell.typeImageView.image = [UIImage imageNamed:@"print_image_1.png"];
            
        }
    }
    
    
    
    
    
//    cell.selectionStyle = UITableViewCellSelectionStyleNone;
//    cell.timeButtonBlock =  ^(id sender){
//        
//        [self pressTimeButtonBlock:sender];
//    };
//    
//    cell.timeBlock = ^(NSString * startTime, NSString * endTime){
//        
//        [self tableCellStartTime:startTime endTime:endTime];
//    };
//    [cell loadDataWithHospitalInfo:self.detailsService listInfo:self.infoModel];
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    CBPeripheral * per = _peripheralList[indexPath.row];
    
    
    if (_manager._per) {
        if ([_manager._per.identifier isEqual:per.identifier]) {//如果有链接 断开
            
            [_manager cancelPeripheralWith:per];
            [self.myTableView reloadData];
            return;
        }
    }
    
    //如果没有链接  连接
    [_manager connectPeripheralWith:per];
    [_manager connectInfoReturn:^(CBCentralManager *central, CBPeripheral *peripheral, NSString *stateStr) {
        if ([stateStr isEqualToString:@"SUCCESS"]) {//连接成功--SUCCESS，连接失败--ERROR，断开连接--DISCONNECT
            [SVProgressHUD showSuccessWithStatus:@"连接蓝牙设备成功!" maskType:SVProgressHUDMaskTypeNone];
            NSLog(@"id = %@", per.identifier);
            [NSTimer scheduledTimerWithTimeInterval:2.0f target:self selector:@selector(BlueToothPrint) userInfo:nil repeats:NO];
        }else if([stateStr isEqualToString:@"ERROR"]){
            [SVProgressHUD showInfoWithStatus:@"蓝牙打印机连接失败，正在重试"];
            [self saomiao];
        }else if([stateStr isEqualToString:@"BLUEDISS"]){
            UIAlertView *alertaa = [[UIAlertView alloc]initWithTitle:@"提示" message:@"请连接有效的蓝牙打印设备!!!" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
            [alertaa show];
        }else{
            [SVProgressHUD showInfoWithStatus:@"蓝牙打印机断开连接，正在重试"];
            [self saomiao];
        }
        [self.myTableView reloadData];
    }];
    
}
-(void)BlueToothPrint{
    
    
    [_manager getBluetoothPrintWith:self.responseInfo andPrintType:0];
    [_manager stopScan];
    [_manager getPrintSuccessReturn:^(BOOL sizeValue) {
        if (sizeValue==YES) {
            [SVProgressHUD showSuccessWithStatus:@"打印成功!" maskType:SVProgressHUDMaskTypeNone];
            [self.navigationController popViewControllerAnimated:YES];
        }else{
            [SVProgressHUD showInfoWithStatus:@"打印失败!"];
        }
        [self dismissViewControllerAnimated:YES completion:nil];
    }];
}

//扫描设备
-(void)saomiao{
    [_manager stopScan];
    [_manager startScan];
    [NSTimer scheduledTimerWithTimeInterval:1.5f target:self selector:@selector(getNameListInfo) userInfo:nil repeats:NO];
}


- (IBAction)pressDoBack:(id)sender{

    [self dismissViewControllerAnimated:YES completion:nil];
}


@end
